import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:lista_tareas_filtros/providers/tarea_provider.dart';
import 'package:lista_tareas_filtros/widgets/tarjeta_tarea.dart';
import 'package:lista_tareas_filtros/widgets/custom_scaffold.dart';
import 'package:provider/provider.dart';

/// Pantalla principal de la aplicación de tareas.
/// Muestra la lista de tareas filtradas y permite cambiar entre modo oscuro/claro,
/// así como filtrar tareas por categoría y estado.
class PaginaPrincipal extends StatefulWidget {
  const PaginaPrincipal({super.key});

  @override
  PaginaPrincipalState createState() => PaginaPrincipalState();
}

class PaginaPrincipalState extends State<PaginaPrincipal> {
  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    // Carga las tareas al construir el widget. Solo se llama una vez al entrar a la pantalla.
    Provider.of<TareaProvider>(context, listen: false).cargarDatos();
  }

  @override
  Widget build(BuildContext context) {
    // Obtenemos el provider que contiene la lógica y estado de las tareas
    final tareaProvider = Provider.of<TareaProvider>(context);

    return CustomScaffold(
      // Parte superior derecha: interruptor para modo oscuro/claro
      actions: [
        Switch(
          value: tareaProvider.isDarkTheme,
          onChanged: (value) {
            tareaProvider.alternarTema(value); // Cambia el tema global
          },
        ),
      ],

      // Cuerpo principal de la pantalla
      body: Column(
        children: [
          // Filtros de tareas (categoría y estado)
          Container(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'Filtrar Tareas',
                  style: TextStyle(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 8),

                // Dropdown para filtrar por categoría
                _buildFilterDropdown(
                  context: context,
                  value: tareaProvider.filtroCategoria,
                  items: const [
                    DropdownMenuItem(value: 'Todas', child: Text('Todas las categorías')),
                    DropdownMenuItem(value: 'General', child: Text('General')),
                    DropdownMenuItem(value: 'Trabajo', child: Text('Trabajo')),
                    DropdownMenuItem(value: 'Personal', child: Text('Personal')),
                    DropdownMenuItem(value: 'Estudio', child: Text('Estudio')),
                    DropdownMenuItem(value: 'Otro', child: Text('Otro')),
                  ],
                  hint: 'Seleccionar categoría',
                  onChanged: (value) {
                    tareaProvider.cambiarFiltroCategoria(value!);
                  },
                ),

                const SizedBox(height: 8),

                // Dropdown para filtrar por estado (pendiente o completada)
                _buildFilterDropdown(
                  context: context,
                  value: tareaProvider.filtroEstado,
                  items: const [
                    DropdownMenuItem(value: 'Todas', child: Text('Todas las tareas')),
                    DropdownMenuItem(value: 'Pendientes', child: Text('Pendientes')),
                    DropdownMenuItem(value: 'Completadas', child: Text('Completadas')),
                  ],
                  hint: 'Seleccionar estado',
                  onChanged: (value) {
                    tareaProvider.cambiarFiltroEstado(value!);
                  },
                ),
              ],
            ),
          ),

          // Lista de tareas filtradas
          Expanded(
            child: tareaProvider.tareasFiltradas.isEmpty
                // Si no hay tareas, muestra un mensaje amigable
                ? const Center(
                    child: Text(
                      'No hay tareas. Agrega una nueva.',
                      style: TextStyle(color: Colors.grey),
                    ),
                  )
                // Si hay tareas, crea una lista con ellas
                : ListView.builder(
                    padding: const EdgeInsets.all(8.0),
                    itemCount: tareaProvider.tareasFiltradas.length,
                    itemBuilder: (context, indice) {
                      return TarjetaTarea(
                        tarea: tareaProvider.tareasFiltradas[indice],
                        indice: indice,
                      );
                    },
                  ),
          ),
        ],
      ),

      // Botón flotante para agregar nueva tarea
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          context.push('/agregar'); // Navega a la pantalla de agregar tarea
        },
        tooltip: 'Agregar nueva tarea',
        child: const Icon(Icons.add),

      ),
    );
  }

  /// Método auxiliar para construir un Dropdown con filtros.
  /// Reutiliza este widget tanto para categorías como para estado.
  Widget _buildFilterDropdown({
    required BuildContext context,
    required String value,
    required List<DropdownMenuItem<String>> items,
    required String hint,
    required Function(String?) onChanged,
  }) {
    return DropdownButton<String>(
      value: value,           // Valor actual seleccionado
      isExpanded: true,       // Ocupa todo el ancho disponible
      items: items,           // Lista de opciones
      onChanged: onChanged,   // Función al cambiar valor
      hint: Text(hint),       // Texto cuando no hay selección
    );
  }
}
