import 'package:flutter/material.dart';
import 'package:lista_tareas_filtros/models/tarea.dart';
import 'package:lista_tareas_filtros/providers/tarea_provider.dart';
import 'package:lista_tareas_filtros/widgets/custom_scaffold.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';

/// Página de creación de una nueva tarea.
/// Usa Provider para acceder al estado global de las tareas y GoRouter para navegación.
class PaginaAgregarTarea extends StatefulWidget {
  const PaginaAgregarTarea({super.key});

  @override
  PaginaAgregarTareaState createState() => PaginaAgregarTareaState();
}

class PaginaAgregarTareaState extends State<PaginaAgregarTarea> {
  // Controladores para los campos de texto (título y descripción).
  final TextEditingController _controladorTitulo = TextEditingController();
  final TextEditingController _controladorDescripcion = TextEditingController();

  // Categoría inicial por defecto
  String _categoriaSeleccionada = 'General';

  @override
  void dispose() {
    // Liberamos los recursos cuando la pantalla se destruye.
    _controladorTitulo.dispose();
    _controladorDescripcion.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    // Obtenemos el provider para agregar tareas sin escuchar actualizaciones.
    final tareaProvider = Provider.of<TareaProvider>(context, listen: false);

    return CustomScaffold( // Scaffold personalizado para mantener estilo coherente
      body: Padding(
        padding: const EdgeInsets.all(8.0), // Espaciado general interno
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Crear Nueva Tarea',
              style: TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),

            const SizedBox(height: 8),

            // Campo de texto para el título de la tarea
            TextField(
              controller: _controladorTitulo,
              decoration: const InputDecoration(
                labelText: 'Título de la tarea',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.title), // Icono decorativo (mejora UX)
              ),
            ),

            const SizedBox(height: 8),

            // Campo de texto multilínea para descripción (opcional)
            TextField(
              controller: _controladorDescripcion,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Descripción (opcional)',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.description),
              ),
            ),

            const SizedBox(height: 8),

            // Dropdown para seleccionar categoría de la tarea
            DropdownButtonFormField<String>(
              initialValue: _categoriaSeleccionada,
              decoration: const InputDecoration(
                labelText: 'Categoría',
                border: OutlineInputBorder(),
                prefixIcon: Icon(Icons.category),
              ),
              items: const [
                DropdownMenuItem(value: 'General', child: Text('General')),
                DropdownMenuItem(value: 'Trabajo', child: Text('Trabajo')),
                DropdownMenuItem(value: 'Personal', child: Text('Personal')),
                DropdownMenuItem(value: 'Estudio', child: Text('Estudio')),
                DropdownMenuItem(value: 'Otro', child: Text('Otro')),
              ],
              onChanged: (value) {
                // Actualizamos el estado con la categoría seleccionada
                setState(() {
                  _categoriaSeleccionada = value!;
                });
              },
            ),

            const SizedBox(height: 16),

            // Botón centrado para crear la tarea
            Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.check),
                label: const Text('Crear Tarea'),
                onPressed: () {
                  // Validamos que el título no esté vacío
                  if (_controladorTitulo.text.isNotEmpty) {
                    // Creamos el objeto Tarea
                    final nuevaTarea = Tarea(
                      titulo: _controladorTitulo.text,
                      descripcion: _controladorDescripcion.text,
                      categoria: _categoriaSeleccionada,
                    );

                    // Añadimos la tarea al Provider
                    tareaProvider.agregarTarea(nuevaTarea);

                    // Volvemos a la pantalla anterior
                    context.pop();
                  } else {
                    // Mostramos feedback si el campo título está vacío
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('El título es obligatorio'),
                        behavior: SnackBarBehavior.floating,
                      ),
                    );
                  }
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}
