import 'package:flutter/material.dart';
import 'package:lista_tareas_filtros/providers/tarea_provider.dart'; // Gestión de estado global
import 'package:lista_tareas_filtros/routes/rutas.dart'; // Definición de rutas para navegación
import 'package:provider/provider.dart';

void main() async {
  // Asegura que los plugins y servicios estén correctamente inicializados antes de usar.
  WidgetsFlutterBinding.ensureInitialized();

  // Creamos una instancia del provider que manejará las tareas
  final tareaProvider = TareaProvider();

  // Cargamos los datos guardados previamente (simulación persistencia)
  await tareaProvider.cargarDatos();

  // Lanzamos la app envuelta en un ChangeNotifierProvider para inyectar el estado global
  runApp(
    ChangeNotifierProvider.value(
      value: tareaProvider,
      child: const AplicacionTareas(),
    ),
  );
}

/// Widget raíz de la aplicación
/// Encargado de configurar el tema (claro/oscuro), título, y sistema de navegación
class AplicacionTareas extends StatelessWidget {
  const AplicacionTareas({super.key});

  @override
  Widget build(BuildContext context) {
    // Accede al estado para determinar si usar tema claro u oscuro
    final temaProvider = Provider.of<TareaProvider>(context);

    return MaterialApp.router(
      debugShowCheckedModeBanner: false, // Quita la cinta de "debug" en la esquina
      title: 'Lista de Tareas con Filtros',

      // Tema claro (modo por defecto)
      theme: ThemeData(
        primaryColor: Colors.blue,
        scaffoldBackgroundColor: Colors.white,
        colorScheme: const ColorScheme.light(
          primary: Colors.blue,
          secondary: Colors.orange,
          surface: Colors.white,
          onPrimary: Colors.black,
          onSecondary: Colors.white,
          onSurface: Colors.black,
          error: Colors.red,
        ),
      ),

      // Tema oscuro opcional
      darkTheme: ThemeData(
        primaryColor: Colors.blue,
        scaffoldBackgroundColor: Colors.grey[900],
        colorScheme: const ColorScheme.dark(
          primary: Colors.blue,
          secondary: Colors.orange,
          surface: Colors.grey,
          onPrimary: Colors.white,
          onSecondary: Colors.black,
          onSurface: Colors.white,
          error: Colors.red,
        ),
      ),

      // Decide cuál usar: claro u oscuro
      themeMode: temaProvider.isDarkTheme ? ThemeMode.dark : ThemeMode.light,

      // Sistema de navegación basado en rutas declaradas con GoRouter
      routerConfig: router,
    );
  }
}
