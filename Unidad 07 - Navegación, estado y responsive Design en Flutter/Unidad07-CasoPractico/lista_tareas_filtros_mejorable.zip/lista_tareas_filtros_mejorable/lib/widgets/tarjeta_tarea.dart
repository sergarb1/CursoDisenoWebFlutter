import 'package:flutter/material.dart';
import 'package:lista_tareas_filtros/models/tarea.dart';
import 'package:lista_tareas_filtros/providers/tarea_provider.dart';
import 'package:provider/provider.dart';

/// Widget que representa una tarjeta visual individual para mostrar una tarea.
/// Utiliza el widget ListTile dentro de una Card para mantener un estilo limpio y funcional.
class TarjetaTarea extends StatelessWidget {
  final Tarea tarea; // Objeto que contiene los datos de la tarea
  final int indice;  // Índice en la lista de tareas

  const TarjetaTarea({
    super.key,
    required this.tarea,
    required this.indice,
  });

  @override
  Widget build(BuildContext context) {
    // Acceso al provider para modificar tareas (cambiar estado o eliminar)
    final tareaProvider = Provider.of<TareaProvider>(context, listen: false);

    return Card(
      // Card da un efecto de tarjeta elevada, útil para distinguir visualmente elementos de lista
      child: ListTile(
        // Checkbox al inicio de la tarjeta para marcar como completada
        leading: Checkbox(
          value: tarea.estaCompletada,
          onChanged: (value) =>
              tareaProvider.cambiarEstadoTarea(indice), // Alternar estado
        ),

        // Título de la tarea. Si está completada, se tacha visualmente.
        title: Text(
          tarea.titulo,
          style: TextStyle(
            decoration: tarea.estaCompletada
                ? TextDecoration.lineThrough // Tachado si completada
                : null,
          ),
        ),

        // Subtítulo solo se muestra si hay descripción
        subtitle: tarea.descripcion.isNotEmpty
            ? Text(tarea.descripcion)
            : null,

        // Botón de borrar la tarea (ícono de papelera)
        trailing: IconButton(
          icon: const Icon(Icons.delete),
          onPressed: () =>
              tareaProvider.eliminarTarea(indice), // Eliminar al pulsar
        ),
      ),
    );
  }
}
