import 'package:flutter/material.dart';
import 'package:lista_tareas_filtros/widgets/logo.dart';

/// Widget reutilizable que encapsula el diseño base de todas las pantallas.
/// Incluye AppBar con logo, cuerpo principal y botón flotante opcional.
/// Este patrón permite mantener la coherencia visual en toda la app.
class CustomScaffold extends StatelessWidget {
  // Lista opcional de widgets que se colocan a la derecha del AppBar (como el switch de tema)
  final List<Widget>? actions;

  // Contenido principal de la pantalla
  final Widget body;

  // Botón flotante opcional (por ejemplo, para agregar tarea)
  final Widget? floatingActionButton;

  const CustomScaffold({
    super.key,
    this.actions,
    required this.body,
    this.floatingActionButton,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar personalizado
      appBar: AppBar(
        // Widget del logo institucional, centrado
        title: const Logo(),
        centerTitle: true,
        // Acciones opcionales (por ejemplo: botón de configuración, switch de tema, etc.)
        actions: actions,
      ),

      // Cuerpo principal de la pantalla, pasado desde el widget padre
      body: body,

      // Botón flotante que aparece sobre la interfaz
      floatingActionButton: floatingActionButton,

      // Pie de página con información legal o institucional
      bottomNavigationBar: const Padding(
        padding: EdgeInsets.all(8.0),
        child: Text(
          'Copyright 2025 - Lista de tareas con filtros',
          textAlign: TextAlign.center,
          style: TextStyle(fontSize: 12, color: Colors.grey),
        ),
      ),
    );
  }
}
