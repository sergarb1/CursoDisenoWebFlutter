import 'package:flutter/material.dart';

// Punto de entrada de la aplicación
void main() {
  runApp(const BolsaEmpleoApp());
}

// Widget principal que configura la app
class BolsaEmpleoApp extends StatelessWidget {
  const BolsaEmpleoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bolsa de Empleo',
      debugShowCheckedModeBanner: false, // Oculta el banner DEBUG
      home: const RegistroPage(),        // Pantalla inicial
    );
  }
}

// Página principal donde se construye el formulario
class RegistroPage extends StatefulWidget {
  const RegistroPage({super.key});

  @override
  State<RegistroPage> createState() => _RegistroPageState();
}

class _RegistroPageState extends State<RegistroPage> {
  // Clave para manejar el formulario
  final _formKey = GlobalKey<FormState>();

  // Variables que guardan el estado de validación de cada campo
  bool _nombreValido = false;
  bool _emailValido = false;
  bool _telefonoValido = false;
  bool _aceptaPolitica = false;

  // Controladores para obtener los valores escritos por el usuario
  final _nombreController = TextEditingController();
  final _emailController = TextEditingController();
  final _telefonoController = TextEditingController();
  final _linkedinController = TextEditingController();

  // Getter que indica si todos los campos son válidos
  bool get _formularioValido =>
      _nombreValido && _emailValido && _telefonoValido && _aceptaPolitica;

  // Libera los recursos de los controladores cuando se destruye el widget
  @override
  void dispose() {
    _nombreController.dispose();
    _emailController.dispose();
    _telefonoController.dispose();
    _linkedinController.dispose();
    super.dispose();
  }

  // Verifica la validez de todos los campos
  void _validarFormulario() {
    setState(() {
      _nombreValido = _nombreController.text.trim().isNotEmpty;

      _emailValido = RegExp(r'^[^@]+@[^@]+\.[^@]+')
          .hasMatch(_emailController.text.trim());

      _telefonoValido = RegExp(r'^[0-9]{9}$')
          .hasMatch(_telefonoController.text.trim());
    });
  }

  // Muestra una notificación si el formulario es válido
  void _enviarFormulario() {
    if (_formularioValido) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Formulario enviado correctamente ✅')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // Barra superior con el título de la app
      appBar: AppBar(title: const Text('Bolsa de Empleo del Instituto')),

      // Hacemos que el contenido sea desplazable (útil en pantallas pequeñas)
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16), // Margen externo general

        child: Form(
          key: _formKey,
          onChanged: _validarFormulario, // Cada vez que cambia el formulario, validamos

          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              // ENCABEZADO con logo y título
              Center(
                child: Column(
                  children: [
                    // Imagen/logo institucional
                    Image.asset(
                      'assets/images/logo.png',
                      height: 100,
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Registro Bolsa de Empleo',
                      style:
                          TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                    ),
                  ],
                ),
              ),

              const SizedBox(height: 24),

              // CAMPO: Nombre completo
              TextFormField(
                controller: _nombreController,
                decoration: InputDecoration(
                  labelText: 'Nombre completo *',

                  // Icono dinámico que cambia según si el campo es válido
                  suffixIcon: Icon(
                    _nombreValido ? Icons.check_circle : Icons.error_outline,
                    color: _nombreValido ? Colors.green : Colors.red,
                  ),

                  // Texto de ayuda contextual
                  helperText: _nombreValido
                      ? 'Nombre válido'
                      : 'Este campo es obligatorio',
                ),
              ),
              const SizedBox(height: 16),

              // CAMPO: Correo electrónico
              TextFormField(
                controller: _emailController,
                decoration: InputDecoration(
                  labelText: 'Correo electrónico *',
                  suffixIcon: Icon(
                    _emailValido ? Icons.check_circle : Icons.error_outline,
                    color: _emailValido ? Colors.green : Colors.red,
                  ),
                  helperText: _emailValido
                      ? 'Correo válido'
                      : 'Introduce un correo válido',
                ),
                keyboardType: TextInputType.emailAddress,
              ),
              const SizedBox(height: 16),

              // CAMPO: Teléfono
              TextFormField(
                controller: _telefonoController,
                decoration: InputDecoration(
                  labelText: 'Teléfono *',
                  suffixIcon: Icon(
                    _telefonoValido ? Icons.check_circle : Icons.error_outline,
                    color: _telefonoValido ? Colors.green : Colors.red,
                  ),
                  helperText: _telefonoValido
                      ? 'Número válido'
                      : 'Debe tener 9 dígitos numéricos',
                ),
                keyboardType: TextInputType.phone,
              ),
              const SizedBox(height: 16),

              // CAMPO: LinkedIn (opcional)
              TextFormField(
                controller: _linkedinController,
                decoration: const InputDecoration(
                  labelText: 'Perfil de LinkedIn (opcional)',
                  helperText: 'Puedes dejarlo en blanco',
                ),
              ),
              const SizedBox(height: 24),

              // CHECKBOX: Aceptación de política de privacidad
              Row(
                children: [
                  Checkbox(
                    value: _aceptaPolitica,
                    onChanged: (v) =>
                        setState(() => _aceptaPolitica = v ?? false),
                  ),
                  const Expanded(
                    child: Text(
                      'Acepto la política de privacidad *',
                      style: TextStyle(fontSize: 14),
                    ),
                  ),
                ],
              ),

              const SizedBox(height: 24),

              // BOTÓN de envío
              SizedBox(
                width: double.infinity, // Ocupa todo el ancho disponible
                child: ElevatedButton(
                  onPressed: _formularioValido
                      ? _enviarFormulario
                      : null, // Solo se activa si el formulario es válido
                  child: const Text('Enviar'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
