package com.example.registro_bolsa_trabajo_mejorable

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
