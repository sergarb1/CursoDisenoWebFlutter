package com.example.registro_bolsa_trabajo_mejorado

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
