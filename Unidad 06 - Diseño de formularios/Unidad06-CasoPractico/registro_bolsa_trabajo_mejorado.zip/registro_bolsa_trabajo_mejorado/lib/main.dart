import 'package:flutter/material.dart';

// Punto de entrada de la aplicación
void main() {
  runApp(const BolsaEmpleoApp());
}

// Widget principal que configura el MaterialApp y el tema visual
class BolsaEmpleoApp extends StatelessWidget {
  const BolsaEmpleoApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Bolsa de Empleo',
      debugShowCheckedModeBanner: false,

      // 🎨 Aplicamos Material 3 y una paleta de color basada en Indigo
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),

        // 🧩 Definimos el estilo global de los campos de texto
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(), // Bordes visibles para claridad
          filled: true,
          fillColor: Color(0xFFF7F9FB), // Fondo suave que reduce fatiga visual
          contentPadding: EdgeInsets.symmetric(horizontal: 16, vertical: 12),
        ),
      ),

      // Página de inicio
      home: const RegistroPage(),
    );
  }
}

// Widget de la pantalla de registro
class RegistroPage extends StatefulWidget {
  const RegistroPage({super.key});

  @override
  State<RegistroPage> createState() => _RegistroPageState();
}

class _RegistroPageState extends State<RegistroPage> {
  // Llave para validar el formulario
  final _formKey = GlobalKey<FormState>();

  // Controladores para cada campo del formulario
  final _nombreController = TextEditingController();
  final _emailController = TextEditingController();
  final _telefonoController = TextEditingController();
  final _linkedinController = TextEditingController();

  // Estado del checkbox de aceptación de política
  bool _aceptaPolitica = false;

  // Getter que indica si el formulario completo es válido
  bool get _formularioValido =>
      _formKey.currentState?.validate() == true && _aceptaPolitica;

  // Liberamos memoria al cerrar
  @override
  void dispose() {
    _nombreController.dispose();
    _emailController.dispose();
    _telefonoController.dispose();
    _linkedinController.dispose();
    super.dispose();
  }

  // Acción al pulsar "Enviar"
  void _enviarFormulario() {
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('✅ Formulario enviado correctamente'),
        behavior: SnackBarBehavior.floating,
      ),
    );
  }

  // ----------------------------
  // VALIDACIONES DE LOS CAMPOS
  // ----------------------------

  String? _validarNombre(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'El nombre es obligatorio';
    }
    if (valor.trim().length < 3) {
      return 'Debe tener al menos 3 caracteres';
    }
    return null;
  }

  String? _validarEmail(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'El correo es obligatorio';
    }
    final emailRegExp = RegExp(r'^[^@]+@[^@]+\.[^@]+');
    if (!emailRegExp.hasMatch(valor.trim())) {
      return 'Correo no válido';
    }
    return null;
  }

  String? _validarTelefono(String? valor) {
    if (valor == null || valor.trim().isEmpty) {
      return 'El teléfono es obligatorio';
    }
    final telRegExp = RegExp(r'^[0-9]{9}$');
    if (!telRegExp.hasMatch(valor.trim())) {
      return 'Debe tener 9 dígitos';
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;

    return Scaffold(
      // 🎨 AppBar con colores suaves y centro visual
      appBar: AppBar(
        backgroundColor: color.primaryContainer,
        foregroundColor: color.onPrimaryContainer,
        title: const Text('Bolsa de Empleo del Instituto'),
        centerTitle: true,
      ),

      // Hacemos scrollable el contenido
      body: SingleChildScrollView(
        physics: const BouncingScrollPhysics(), // Scroll fluido
        padding: const EdgeInsets.all(24), // Margen externo

        child: Column(
          children: [
            // ----------------------------
            // ENCABEZADO VISUAL
            // ----------------------------
            Center(
              child: Column(
                children: [
                  // Widget que recorta la imagen con esquinas redondeadas y borde negro alrededor
                  Container(
                    decoration: BoxDecoration(
                      border: Border.all(
                        color: Colors.black, // Color del borde: negro
                        width: 0.5, // Grosor del borde
                      ),
                      borderRadius: BorderRadius.circular(
                        16,
                      ), // Esquinas redondeadas del borde
                    ),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(
                        16,
                      ), // Esquinas redondeadas aplicadas a la imagen
                      child: Image.asset(
                        'assets/images/logo.png',
                        height: 100,
                        fit: BoxFit
                            .cover, // Ajusta la imagen para cubrir el área, recortando si es necesario
                      ),
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Título con estilo institucional
                  Text(
                    'Registro Bolsa de Empleo',
                    style: Theme.of(context).textTheme.titleLarge?.copyWith(
                      color: color.primary,
                      fontWeight: FontWeight.bold,
                    ),
                  ),

                  const SizedBox(height: 4),

                  // Subtítulo explicativo
                  Text(
                    'Completa tus datos para formar parte de nuestra bolsa de empleo',
                    textAlign: TextAlign.center,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                      color: color.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ----------------------------
            // FORMULARIO DE REGISTRO
            // ----------------------------
            Form(
              key: _formKey,
              onChanged: () => setState(() {}), // Refresca validez al escribir
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildCampo(
                    label: 'Nombre completo *',
                    controller: _nombreController,
                    validator: _validarNombre,
                    icon: Icons.person,
                  ),
                  const SizedBox(height: 16),
                  _buildCampo(
                    label: 'Correo electrónico *',
                    controller: _emailController,
                    validator: _validarEmail,
                    icon: Icons.email,
                    keyboardType: TextInputType.emailAddress,
                  ),
                  const SizedBox(height: 16),
                  _buildCampo(
                    label: 'Teléfono *',
                    controller: _telefonoController,
                    validator: _validarTelefono,
                    icon: Icons.phone,
                    keyboardType: TextInputType.phone,
                  ),
                  const SizedBox(height: 16),
                  _buildCampo(
                    label: 'Perfil de LinkedIn (opcional)',
                    controller: _linkedinController,
                    icon: Icons.link,
                  ),
                  const SizedBox(height: 24),

                  // ----------------------------
                  // CHECKBOX POLÍTICA PRIVACIDAD
                  // ----------------------------
                  AnimatedContainer(
                    duration: const Duration(milliseconds: 300),
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(12),
                      color: _aceptaPolitica
                          ? color.primaryContainer.withOpacity(0.3)
                          : Colors.transparent,
                    ),
                    padding: const EdgeInsets.symmetric(horizontal: 8),
                    child: Row(
                      children: [
                        Checkbox(
                          value: _aceptaPolitica,
                          onChanged: (v) =>
                              setState(() => _aceptaPolitica = v ?? false),
                        ),
                        const Expanded(
                          child: Text(
                            'Acepto la política de privacidad *',
                            style: TextStyle(fontSize: 14),
                          ),
                        ),
                      ],
                    ),
                  ),

                  const SizedBox(height: 24),

                  // ----------------------------
                  // BOTÓN DE ENVÍO
                  // ----------------------------
                  SizedBox(
                    width: double.infinity,
                    child: FilledButton.icon(
                      onPressed: _formularioValido ? _enviarFormulario : null,
                      icon: const Icon(Icons.send),
                      label: const Text('Enviar formulario'),
                    ),
                  ),
                ],
              ),
            ),

            const SizedBox(height: 32),

            // ----------------------------
            // PIE DE PÁGINA
            // ----------------------------
            Text(
              '© 2025 IES Serra Perenxisa — Bolsa de Empleo',
              style: Theme.of(
                context,
              ).textTheme.bodySmall?.copyWith(color: color.onSurfaceVariant),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  // ----------------------------
  // MÉTODO PERSONALIZADO PARA CREAR CAMPOS DE TEXTO
  // ----------------------------
  Widget _buildCampo({
    required String label,
    required TextEditingController controller,
    String? Function(String?)? validator,
    IconData? icon,
    TextInputType? keyboardType,
  }) {
    // Determina si el campo es válido actualmente
    final valido = validator == null
        ? true
        : validator(controller.text) == null;
    final color = Theme.of(context).colorScheme;

    return AnimatedContainer(
      duration: const Duration(milliseconds: 300),
      child: TextFormField(
        controller: controller,
        validator: validator,
        keyboardType: keyboardType,
        decoration: InputDecoration(
          labelText: label,
          prefixIcon: Icon(icon, color: color.primary), // Icono a la izquierda
          suffixIcon: Icon(
            // Icono dinámico según validez
            valido ? Icons.check_circle : Icons.error_outline,
            color: valido ? Colors.green : Colors.redAccent,
          ),
          helperText: valido
              ? 'Campo válido'
              : 'Revisa este campo', // Mensaje contextual
        ),
      ),
    );
  }
}
