import 'package:flutter/material.dart';

// Punto de entrada de la app
void main() {
  runApp(const MyApp());
}

// Widget raíz que configura el tema visual y lanza la pantalla principal
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Currículum Juan Pérez',
      debugShowCheckedModeBanner: false, // Oculta la etiqueta DEBUG en pantalla

      // Definición del tema general de la app
      theme: ThemeData(
        useMaterial3: true, // Activa Material 3 (diseño moderno de Google)

        // Paleta de colores basada en un color semilla
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),

        // Tipografías base reutilizables en toda la app (jerarquía visual)
        textTheme: const TextTheme(
          titleLarge: TextStyle(fontSize: 22, fontWeight: FontWeight.bold), // Titulares grandes
          titleMedium: TextStyle(fontSize: 18, fontWeight: FontWeight.w600), // Títulos de sección
          bodyMedium: TextStyle(fontSize: 16), // Texto normal
        ),
      ),

      // Pantalla inicial del CV
      home: const CurriculumPage(),
    );
  }
}

// Pantalla principal del currículum
class CurriculumPage extends StatelessWidget {
  const CurriculumPage({super.key});

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme; // Accedemos a los colores del tema

    return Scaffold(
      // AppBar con colores personalizados desde el tema
      appBar: AppBar(
        backgroundColor: color.primaryContainer,
        foregroundColor: color.onPrimaryContainer,
        title: const Text('Currículum de Juan Pérez'),
        centerTitle: true,
      ),

      // Contenido principal con scroll
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        physics: const BouncingScrollPhysics(), // Efecto de rebote al hacer scroll (estético)

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [

            // ===================
            // ENCABEZADO PRINCIPAL
            // ===================
            Center(
              child: Column(
                children: [
                  // Avatar con imagen profesional
                  const CircleAvatar(
                    radius: 50,
                    backgroundImage: AssetImage('images/profile.png'),
                    backgroundColor: Colors.transparent,
                  ),
                  const SizedBox(height: 12),

                  // Nombre destacado (jerarquía visual fuerte)
                  Text(
                    'Juan Pérez García',
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(color: color.primary), // Color de marca
                  ),
                  const SizedBox(height: 4),

                  // Rol profesional con estilo secundario
                  Text(
                    'Desarrollador Flutter',
                    style: Theme.of(context)
                        .textTheme
                        .bodyMedium
                        ?.copyWith(color: color.onSurfaceVariant),
                  ),

                  const SizedBox(height: 16),

                  // Información de contacto con iconografía
                  Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: const [
                      Icon(Icons.email, size: 20),
                      SizedBox(width: 6),
                      Text('juan.perez@example.com'),
                      SizedBox(width: 16),
                      Icon(Icons.phone, size: 20),
                      SizedBox(width: 6),
                      Text('+34 600 123 456'),
                    ],
                  ),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // =======================
            // SECCIÓN: EXPERIENCIA
            // =======================
            _SectionCard(
              icon: Icons.work,
              title: 'Experiencia Laboral',

              // Lista de experiencias como columna personalizada
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  _ExperienceItem(
                    puesto: 'Desarrollador Flutter',
                    empresa: 'Empresa XYZ',
                    periodo: '2022 - Actualidad',
                    descripcion:
                        '• Desarrollo de apps móviles multiplataforma.\n'
                        '• Interfaces responsivas.\n'
                        '• APIs REST y Firebase.',
                  ),
                  SizedBox(height: 12),
                  _ExperienceItem(
                    puesto: 'Técnico Informático',
                    empresa: 'Empresa ABC',
                    periodo: '2020 - 2022',
                    descripcion:
                        '• Soporte técnico y mantenimiento de equipos.\n'
                        '• Redes y sistemas Windows/Linux.',
                  ),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // =======================
            // SECCIÓN: EDUCACIÓN
            // =======================
            _SectionCard(
              icon: Icons.school,
              title: 'Educación',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text(
                    'Grado Superior en Desarrollo de Aplicaciones Multiplataforma',
                    style: TextStyle(fontWeight: FontWeight.w600),
                  ),
                  Text('IES Serra Perenxisa — 2018 - 2020'),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // =======================
            // SECCIÓN: HABILIDADES
            // =======================
            _SectionCard(
              icon: Icons.star,
              title: 'Habilidades',

              // Chips con habilidades como elementos visuales destacados
              child: Wrap(
                spacing: 8,
                runSpacing: 8,
                children: [
                  _SkillChip('Flutter'),
                  _SkillChip('Dart'),
                  _SkillChip('Firebase'),
                  _SkillChip('Git'),
                  _SkillChip('SQL'),
                  _SkillChip('Python'),
                  _SkillChip('UI Design'),
                ],
              ),
            ),

            const SizedBox(height: 16),

            // =======================
            // SECCIÓN: IDIOMAS
            // =======================
            _SectionCard(
              icon: Icons.language,
              title: 'Idiomas',
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: const [
                  Text('• Español — Nativo'),
                  Text('• Inglés — Intermedio (B1)'),
                ],
              ),
            ),

            const SizedBox(height: 24),

            // =======================
            // PIE DE PÁGINA
            // =======================
            Center(
              child: Text(
                '© 2025 Juan Pérez — Flutter Developer',
                style: Theme.of(context)
                    .textTheme
                    .bodySmall
                    ?.copyWith(color: color.onSurfaceVariant),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ==================================
// COMPONENTE: Tarjeta de sección
// ==================================
class _SectionCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final Widget child;

  const _SectionCard({
    required this.icon,
    required this.title,
    required this.child,
  });

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;

    return Card(
      elevation: 3,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)), // Bordes redondeados modernos
      margin: EdgeInsets.zero,

      child: Padding(
        padding: const EdgeInsets.all(16),

        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Encabezado con icono y título
            Row(
              children: [
                Icon(icon, color: color.primary),
                const SizedBox(width: 8),
                Text(
                  title,
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
            const Divider(height: 16), // Separador visual moderno

            // Contenido de la sección
            child,
          ],
        ),
      ),
    );
  }
}

// ==================================
// COMPONENTE: Ítem de experiencia laboral
// ==================================
class _ExperienceItem extends StatelessWidget {
  final String puesto;
  final String empresa;
  final String periodo;
  final String descripcion;

  const _ExperienceItem({
    required this.puesto,
    required this.empresa,
    required this.periodo,
    required this.descripcion,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          puesto,
          style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 16),
        ),
        Text(
          '$empresa — $periodo',
          style: Theme.of(context)
              .textTheme
              .bodySmall
              ?.copyWith(color: Colors.grey[700]), // Texto secundario gris
        ),
        const SizedBox(height: 4),
        Text(descripcion), // Lista de tareas como texto plano con viñetas
      ],
    );
  }
}

// ==================================
// COMPONENTE: Chip de habilidad
// ==================================
class _SkillChip extends StatelessWidget {
  final String label;

  const _SkillChip(this.label);

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme;

    return Chip(
      label: Text(label),
      labelStyle: TextStyle(
        color: color.onPrimaryContainer,
        fontWeight: FontWeight.w500,
      ),
      backgroundColor: color.primaryContainer.withOpacity(0.4), // Fondo suave
      side: BorderSide(color: color.primary.withOpacity(0.3)), // Borde fino sutil
    );
  }
}
