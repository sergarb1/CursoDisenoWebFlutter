package com.example.curriculum_simple_mejorable

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
