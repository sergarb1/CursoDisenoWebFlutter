import 'package:flutter/material.dart';

// Función principal que arranca la aplicación.
void main() {
  runApp(const MyApp());
}

// Widget principal de la app, que configura MaterialApp.
class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Currículum Simple',

      // Definimos el tema visual de la aplicación.
      theme: ThemeData(
        useMaterial3: true,
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue), // Genera una paleta de colores basada en un color semilla.
      ),

      // Página principal de la aplicación.
      home: const CurriculumPage(),

      // Oculta el banner de "debug" en la esquina superior derecha.
      debugShowCheckedModeBanner: false,
    );
  }
}

// Página principal que contiene el contenido del currículum.
class CurriculumPage extends StatelessWidget {
  const CurriculumPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      // AppBar (barra superior) con título centrado.
      appBar: AppBar(
        title: const Text('Currículum de Juan Pérez'),
        centerTitle: true,
      ),

      // Cuerpo de la pantalla que se puede desplazar verticalmente.
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16), // Espaciado general alrededor del contenido.
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start, // Alinea todos los elementos a la izquierda.
          children: [

            // INFORMACIÓN PERSONAL
            const Text(
              'Información Personal',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8), // Espaciado entre secciones
            const Text('Nombre: Juan Pérez García'),
            const Text('Email: juan.perez@example.com'),
            const Text('Teléfono: +34 600 123 456'),
            const Text('Ciudad: Valencia, España'),

            const SizedBox(height: 24), // Separación entre bloques

            // EXPERIENCIA LABORAL
            const Text(
              'Experiencia Laboral',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // Primer trabajo
            const Text(
              'Desarrollador Flutter — Empresa XYZ (2022 - Actualidad)',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const Text(
              '• Desarrollo de aplicaciones móviles multiplataforma.\n'
              '• Implementación de interfaces responsivas y lógicas de negocio.\n'
              '• Colaboración con equipos de diseño y backend.',
            ),

            const SizedBox(height: 16),

            // Segundo trabajo
            const Text(
              'Técnico Informático — Empresa ABC (2020 - 2022)',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const Text(
              '• Mantenimiento de equipos y soporte técnico.\n'
              '• Instalación y configuración de software y redes locales.',
            ),

            const SizedBox(height: 24),

            // EDUCACIÓN
            const Text(
              'Educación',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text(
              'Grado Superior en Desarrollo de Aplicaciones Multiplataforma',
              style: TextStyle(fontWeight: FontWeight.w600),
            ),
            const Text('IES Serra Perenxisa — 2018 - 2020'),

            const SizedBox(height: 24),

            // HABILIDADES
            const Text(
              'Habilidades',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // Lista de habilidades como "chips" que ocupan varias líneas si es necesario.
            Wrap(
              spacing: 8, // Espaciado horizontal entre chips.
              runSpacing: 8, // Espaciado vertical entre líneas de chips.
              children: [
                Chip(label: Text('Flutter')),
                Chip(label: Text('Dart')),
                Chip(label: Text('Firebase')),
                Chip(label: Text('Git')),
                Chip(label: Text('SQL')),
                Chip(label: Text('Python')),
              ],
            ),

            const SizedBox(height: 24),

            // IDIOMAS
            const Text(
              'Idiomas',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            const Text('• Español — Nativo'),
            const Text('• Inglés — Intermedio (B1)'),

            const SizedBox(height: 24),

            // CONTACTO CON ICONOS
            const Text(
              'Contacto',
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),

            // Email con icono
            Row(
              children: const [
                Icon(Icons.email, size: 20),
                SizedBox(width: 8),
                Text('juan.perez@example.com'),
              ],
            ),

            // Teléfono con icono
            Row(
              children: const [
                Icon(Icons.phone, size: 20),
                SizedBox(width: 8),
                Text('+34 600 123 456'),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
